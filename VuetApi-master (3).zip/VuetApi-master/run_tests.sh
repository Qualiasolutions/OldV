#! /bin/bash
python manage.py test