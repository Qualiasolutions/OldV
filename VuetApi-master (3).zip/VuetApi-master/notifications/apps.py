"""NotificationsConfig"""
from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    """NotificationsConfig"""

    default_auto_field = "django.db.models.BigAutoField"
    name = "notifications"
