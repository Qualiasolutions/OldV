from django.contrib import admin

from external_calendars.models import ICalIntegration

admin.site.register(ICalIntegration)
