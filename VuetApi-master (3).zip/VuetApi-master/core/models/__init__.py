# This is needed here for AUTH_USER_MODEL setting to work
from .users.user_models import User
