#! /bin/bash
python manage.py shell < setup_e2e_tests.py