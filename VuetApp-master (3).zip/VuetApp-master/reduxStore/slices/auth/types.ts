type AuthState = {
  username: string;
  jwtAccessToken: string;
  jwtRefreshToken: string;
};

export { AuthState };
