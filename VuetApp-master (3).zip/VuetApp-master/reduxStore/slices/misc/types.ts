export interface MiscState {
  ui: {
    showPremiumModal: boolean;
  };
}
