const SET_PUSH_TOKEN = 'SET_PUSH_TOKEN';

export default {
  SET_PUSH_TOKEN
};

export { SET_PUSH_TOKEN };
