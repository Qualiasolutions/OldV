type NotificationState = {
  pushToken: string;
};

export { NotificationState };
