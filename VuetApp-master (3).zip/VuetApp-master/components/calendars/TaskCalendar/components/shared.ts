export const ITEM_HEIGHT = 80;
