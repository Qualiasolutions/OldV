import MessageList from 'components/organisms/MessageList';

function MessageListScreen() {
  return <MessageList />;
}

export default MessageListScreen;
