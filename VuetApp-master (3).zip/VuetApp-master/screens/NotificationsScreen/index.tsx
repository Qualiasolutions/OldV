function NotificationsScreen() {
  return <></>;
}

export default NotificationsScreen;
