import { ColorName } from 'constants/Colors';

export const backgroundColours = {
  default: 'white'
} as {
  [key: string]: ColorName;
};
