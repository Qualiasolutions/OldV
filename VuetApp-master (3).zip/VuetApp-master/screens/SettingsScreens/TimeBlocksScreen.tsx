import TimeBlocksList from 'components/organisms/TimeBlocksList';

export default function TimeBlocksScreen() {
  return <TimeBlocksList />;
}
