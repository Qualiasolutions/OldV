export default function CategoryPreferencesScreen() {
  return null;
}
