import RoutinesList from 'components/organisms/RoutinesList';

export default function RoutinesScreen() {
  return <RoutinesList />;
}
