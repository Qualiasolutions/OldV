import ReferencesList from 'components/organisms/ReferencesList';

export default function AllReferencesScreen() {
  return <ReferencesList showCategoryHeaders={true} />;
}
