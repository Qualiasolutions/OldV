export type DeleteRequest = {
  id: number;
};
